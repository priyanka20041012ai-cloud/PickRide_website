<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$errors = [];
$editing = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id = (int)($_POST['id'] ?? 0);
        $full_name = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($full_name === '' || $email === '') {
            $errors[] = 'Fill in every field.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Enter a valid email address.';
        } elseif (!$id && $password === '') {
            $errors[] = 'Set a password for the new admin.';
        } elseif ($password !== '' && strlen($password) < 6) {
            $errors[] = 'Password must be at least 6 characters.';
        }

        if (!$errors) {
            $stmt = $pdo->prepare('SELECT id FROM admins WHERE email = ? AND id != ?');
            $stmt->execute([$email, $id]);
            if ($stmt->fetch()) {
                $errors[] = 'An admin with that email already exists.';
            }
        }

        if (!$errors) {
            if ($id) {
                if ($password !== '') {
                    $stmt = $pdo->prepare('UPDATE admins SET full_name=?, email=?, password_hash=? WHERE id=?');
                    $stmt->execute([$full_name, $email, password_hash($password, PASSWORD_DEFAULT), $id]);
                } else {
                    $stmt = $pdo->prepare('UPDATE admins SET full_name=?, email=? WHERE id=?');
                    $stmt->execute([$full_name, $email, $id]);
                }
                if ($id === (int)$_SESSION['admin_id']) {
                    $_SESSION['admin_name'] = $full_name;
                    $_SESSION['admin_email'] = $email;
                }
                flash_set('admin_success', 'Admin account updated.');
            } else {
                $stmt = $pdo->prepare('INSERT INTO admins (full_name, email, password_hash) VALUES (?, ?, ?)');
                $stmt->execute([$full_name, $email, password_hash($password, PASSWORD_DEFAULT)]);
                flash_set('admin_success', 'New admin added — email: ' . $email . ', password: ' . $password . ' (share this with them; it will not be shown again).');
            }
            header('Location: ' . BASE_URL . '/admin/admins.php');
            exit;
        } else {
            if ($id) {
                $editing = ['id' => $id, 'full_name' => $full_name, 'email' => $email];
            }
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id === (int)$_SESSION['admin_id']) {
            $errors[] = 'You cannot delete your own account while logged in as it.';
        } else {
            $pdo->prepare('DELETE FROM admins WHERE id = ?')->execute([$id]);
            header('Location: ' . BASE_URL . '/admin/admins.php');
            exit;
        }
    }
}

if (!$editing && isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT id, full_name, email FROM admins WHERE id = ?');
    $stmt->execute([(int)$_GET['edit']]);
    $editing = $stmt->fetch();
}

$admins = $pdo->query('SELECT id, full_name, email FROM admins ORDER BY full_name')->fetchAll();

$pageTitle = 'Admin accounts';
require __DIR__ . '/includes/admin_header.php';
$adminSuccess = flash_get('admin_success');
?>
<div class="admin-topbar"><h1>Admin accounts</h1></div>

<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
<?php if ($adminSuccess): ?><div class="alert alert-success"><?= e($adminSuccess) ?></div><?php endif; ?>

<div class="card">
  <h3><?= $editing ? 'Edit admin' : 'Add a new admin' ?></h3>
  <form method="post">
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?= e($editing['id'] ?? '') ?>">
    <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">
      <div class="field">
        <label>Full name</label>
        <input type="text" name="full_name" value="<?= e($editing['full_name'] ?? '') ?>" required>
      </div>
      <div class="field">
        <label>Email</label>
        <input type="email" name="email" value="<?= e($editing['email'] ?? '') ?>" required>
      </div>
      <div class="field">
        <label><?= $editing ? 'New password (leave blank to keep current)' : 'Password' ?></label>
        <input type="text" name="password" placeholder="<?= $editing ? 'Leave blank to keep current password' : 'At least 6 characters' ?>" <?= $editing ? '' : 'required' ?>>
      </div>
    </div>
    <button type="submit" class="btn btn-dark"><?= $editing ? 'Save changes' : 'Add admin' ?></button>
    <?php if ($editing): ?><a href="<?= BASE_URL ?>/admin/admins.php" class="btn btn-outline" style="color:var(--ink-900); border-color:var(--border);">Cancel</a><?php endif; ?>
  </form>
</div>

<div class="card" style="display:flex; justify-content:space-between; align-items:center;">
  <span>Download every admin account's name and email for your records.</span>
  <a href="<?= BASE_URL ?>/admin/export.php?type=admins" class="btn btn-outline" style="color:var(--ink-900); border-color:var(--border);">Export admins (CSV)</a>
</div>

<table class="data-table">
  <thead><tr><th>Name</th><th>Email</th><th>Actions</th></tr></thead>
  <tbody>
    <?php foreach ($admins as $a): ?>
      <tr>
        <td><?= e($a['full_name']) ?></td>
        <td><?= e($a['email']) ?></td>
        <td>
          <a href="?edit=<?= e($a['id']) ?>" class="btn btn-small btn-outline" style="color:var(--ink-900); border-color:var(--border);">Edit</a>
          <?php if ((int)$a['id'] !== (int)($_SESSION['admin_id'] ?? 0)): ?>
            <form method="post" style="display:inline;" onsubmit="return confirm('Remove this admin account?');">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= e($a['id']) ?>">
              <button type="submit" class="btn btn-small btn-danger">Delete</button>
            </form>
          <?php else: ?>
            <span style="font-size:0.8rem; color:var(--ink-600);">This is you</span>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>

<?php require __DIR__ . '/includes/admin_footer.php'; ?>
